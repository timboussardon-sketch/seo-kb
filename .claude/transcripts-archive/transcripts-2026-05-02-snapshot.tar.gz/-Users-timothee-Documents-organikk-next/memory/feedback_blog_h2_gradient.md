---
name: Tous les sous-titres majeurs d'article blog doivent être H2 (gradient bleu)
description: Sur les articles blog Organikk, tous les sous-titres de section significatifs doivent être en H2 pour bénéficier du dégradé bleu standard, pas en H3
type: feedback
originSessionId: 47afeba1-0580-4b17-a083-a249a6a7323e
---
Sur les articles `src/data/articles.ts`, tout sous-titre de section majeure doit être `{ type: 'h2' }` pour hériter automatiquement du dégradé bleu défini dans `.article-prose h2` (clamp(26px, 3vw, 32px) + linear-gradient `#0E2A78 → #4685F0 → #7FA9F5` background-clip text). Les H3 restent réservés aux sous-sections internes d'un H2 (ex : « Bloc LLM 50 mots », « Conséquence stratégique », étapes numérotées d'une procédure).

**Why:** Demande explicite de Tim sur l'article reddit-pour-geo (mai 2026) : « tous les titres H2 du contenu doivent être en dégradé » + « pixel perfect comme les autres titres blog ». Cohérence visuelle exigée à travers tout le blog : un sous-titre majeur en H3 casse le rythme typographique et donne une impression d'article mal hiérarchisé.

**How to apply:**
- Quand un article a une intro narrative découpée en sous-sections (cas du retranscript vidéo : « Les chiffres », « Le vrai signal », « Pourquoi ça marche », etc.) → toutes en H2, même si ça produit 10+ entrées dans la TOC
- Le renderer numérote automatiquement les H2 (`01 ·`, `02 ·`...) sauf pour les titres outro (FAQ, À retenir, Pour finir, etc.) — la numérotation longue n'est pas un argument pour rétrograder en H3
- H3 = sous-titre de granularité fine sous un H2 (bullet-style : étape, exemple, bloc extractible, FAQ q/r)
- Vérifier le rendu : `curl ... | grep -oE '<h2[^>]*>'` doit montrer tous les titres majeurs avec la classe/style hérité de `.article-prose h2`
