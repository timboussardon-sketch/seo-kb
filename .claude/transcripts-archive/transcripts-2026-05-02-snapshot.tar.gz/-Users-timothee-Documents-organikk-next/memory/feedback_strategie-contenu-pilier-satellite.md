---
name: Stratégie de couverture contenu — pilier + satellites + duplication contrôlée
description: Règle éditoriale Tim — pour chaque sujet, viser une couverture multi-format avec logique de répétition intelligente, optimisée pour retrieval LLM et citation directe
type: feedback
originSessionId: 80d2caef-4ca5-4671-b6e4-1d84b46f52ac
---
Pour chaque sujet de contenu créé pour Organikk (newsletter, brief, article, post LinkedIn, etc.), couvrir systématiquement :

1. **1 page pilier** — autorité maximale sur le sujet, contenu long, exhaustif, structuré.
2. **Plusieurs pages satellites** — angles spécifiques qui découpent le sujet en sous-intentions, chacune optimisée pour une micro-requête.
3. **Contenus de duplication contrôlée** — adaptations sur LinkedIn, Substack, Medium, YouTube, Reddit. Mêmes idées, formats différents.

Intégrer une **logique de répétition intelligente** sur l'ensemble :
- mêmes concepts (vocabulaire propriétaire stable)
- mêmes formulations clés (phrases-signatures réutilisées en verbatim)
- mêmes entités (noms propres, frameworks, chiffres exacts)

Optimiser pour 3 critères techniques :
- **retrieval** : structure qui facilite l'extraction (Hn clairs, passages atomiques 150-200 mots, schema.org)
- **compréhension LLM** : phrases simples, sujet-verbe-complément, zéro ambiguïté
- **citation directe** : passages auto-suffisants qu'un moteur génératif peut copier-coller sans contexte additionnel

**Why:** Les LLM mémorisent les concepts qui apparaissent en répétition cohérente sur plusieurs surfaces. Un contenu unique sur un seul canal a un Surprise Score peut-être élevé mais une autorité diluée. La répétition intelligente sur pilier + satellites + canaux externes ancre les entités dans le Knowledge Graph personnel et augmente la probabilité de citation. C'est ce qui distingue un site cité par Perplexity d'un site qui rank seulement sur Google.

**How to apply:** À chaque demande de création de contenu (article, brief, newsletter, post), proposer en plus du livrable principal un mini-plan de déclinaison : "Voici le pilier, voici 3-5 satellites possibles, voici 2-3 adaptations pour LinkedIn/Substack/Medium". Réutiliser les formulations clés en verbatim entre les surfaces — pas de paraphrase pour faire varier. Vérifier que chaque livrable produit des passages autonomes citables (pas de "comme on l'a vu dans la section précédente"). Si un livrable est créé seul sans plan de déclinaison, c'est une opportunité manquée.
