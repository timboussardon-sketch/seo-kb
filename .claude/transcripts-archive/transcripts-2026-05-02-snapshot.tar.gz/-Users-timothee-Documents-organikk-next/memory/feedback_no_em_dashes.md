---
name: Pas d'em-dashes dans le contenu publié
description: Tim interdit les em-dashes (—) et en-dashes (–) dans tout le contenu rédactionnel publié sur le site Organikk (articles blog, FAQ, méthode, services)
type: feedback
originSessionId: 47afeba1-0580-4b17-a083-a249a6a7323e
---
Aucun em-dash (—, U+2014) ni en-dash (–, U+2013) dans le contenu publié sur organikk-next : articles de blog, FAQ, pages méthode/services, captions, highlights, méta-descriptions, titres.

**Why:** Demande explicite de Tim sur l'article reddit-pour-geo (mai 2026) : « interdit d'utiliser les dash dans tous le contenu ». Probablement signature anti-IA — l'em-dash est un tic d'écriture LLM massivement détecté comme tel par les lecteurs B2B.

**How to apply:**
- Rédaction d'un nouvel article ou d'un nouveau bloc : remplacer toute pause stylistique par virgule, deux-points, point, ou parenthèses selon le contexte
- Audit avant push : `grep -nP "[—–]"` dans tous les fichiers touchés (`src/data/articles.ts`, `src/app/**/page.tsx`)
- Tirets normaux `-` autorisés (mots composés, listes)
- S'applique aussi aux titres H2/H3 et aux captions
- Le renderer (`src/app/blog/[slug]/page.tsx`) a déjà un `replace(/\s[—–-]\s/g, ' ')` sur les titres H2 — c'est un filet de sécurité, pas une excuse pour en mettre dans la donnée
